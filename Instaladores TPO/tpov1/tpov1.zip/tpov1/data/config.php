<?php
	define('dbHOST',    base64_decode(''));
	define('dbUSER',    base64_decode(''));
	define('dbPASS',    base64_decode(''));
	define('dbNAME',    base64_decode(''));
  define('IURL_ROOT', base64_decode(''));
  define('IDIR_ROOT', base64_decode(''));
  define('IURL_COMUN',base64_decode(''));
 	define('IDIR_COMUN',base64_decode(''));      
?>
