<?php
	define('dbHOST',    base64_decode('bG9jYWxob3N0'));
	define('dbUSER',    base64_decode('aW5zdGFsbA=='));
	define('dbPASS',    base64_decode('aW5zdGFsbA=='));
	define('dbNAME',    base64_decode('aW5zdGFsbA=='));
        define('IURL_ROOT', base64_decode('aHR0cDovL2xvY2FsaG9zdDo4MC9pbmFpL3Rwb2FkbWludjEv'));
        define('IDIR_ROOT', base64_decode('L29wdC9sYW1wcC9odGRvY3MvaW5haS90cG9hZG1pbnYxLw=='));
        define('IURL_COMUN',base64_decode('aHR0cDovL2xvY2FsaG9zdDo4MC9pbmFpLw=='));
 	define('IDIR_COMUN',base64_decode('L29wdC9sYW1wcC9odGRvY3MvaW5haS8='));      
?>
